# Practical 3: Sample variance and standard deviation

## Aim

To calculate the sample variance and sample standard deviation for the given sales data.

Source: Statistics Lab manual-1_organized.pdf, PDF pages 6.

## Run

From the repository root, after installing `requirements.txt`:

```bash
python practical_03_variance_standard_deviation/main.py
```


## Output

See [output.txt](output.txt) for the verified console output.
