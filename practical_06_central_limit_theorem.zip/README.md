# Practical 6: Central Limit Theorem

## Aim

To demonstrate how sample means become more concentrated and approximately normal as sample size increases, using an exponential population.

Source: Statistics Lab manual-1_organized.pdf, PDF pages 9.

## Run

From the repository root, after installing `requirements.txt`:

```bash
python practical_06_central_limit_theorem/main.py
```


Use `--save` to write `chart.png` beside the script without opening a plot window.

![Generated chart](chart.png)

## Output

See [output.txt](output.txt) for the verified console output.
