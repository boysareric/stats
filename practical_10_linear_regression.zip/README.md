# Practical 10: Ordinary least squares regression

## Aim

To compute the regression intercept, slope and R-squared for Sales predicted by TV Spend.

Source: Statistics Lab manual-1_organized.pdf, PDF pages 15-16.

## Run

From the repository root, after installing `requirements.txt`:

```bash
python practical_10_linear_regression/main.py
```


## Output

See [output.txt](output.txt) for the verified console output.
