# Practical 9: Independent two-sample t-test

## Aim

To determine whether the mean performance of Shift A differs significantly from Shift B.

Source: Statistics Lab manual-1_organized.pdf, PDF pages 13-14.

## Run

From the repository root, after installing `requirements.txt`:

```bash
python practical_09_independent_t_test/main.py
```


## Output

See [output.txt](output.txt) for the verified console output.

The manual prints t=-2.490 and p=0.0471. Running its supplied observations with the stated test instead gives t=-3.030 and p=0.0231; the observations are retained.
