# Practical 2: Measures of central tendency

## Aim

To calculate the mean, median and mode for the given sales data.

Source: Statistics Lab manual-1_organized.pdf, PDF pages 5.

## Run

From the repository root, after installing `requirements.txt`:

```bash
python practical_02_central_tendency/main.py
```


All observations occur once, so there is no unique mode. pandas returns every value in this case.

## Output

See [output.txt](output.txt) for the verified console output.
