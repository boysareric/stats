# Practical 8: One-sample t-test

## Aim

To test whether the mean bottle volume differs significantly from 500 ml.

Source: Statistics Lab manual-1_organized.pdf, PDF pages 12.

## Run

From the repository root, after installing `requirements.txt`:

```bash
python practical_08_one_sample_t_test/main.py
```


## Output

See [output.txt](output.txt) for the verified console output.
