# Practical 5: Poisson probability distribution

## Aim

To generate the Poisson PMF for an average rate of 4 complaints per day and plot the distribution.

Source: Statistics Lab manual-1_organized.pdf, PDF pages 8.

## Run

From the repository root, after installing `requirements.txt`:

```bash
python practical_05_poisson_distribution/main.py
```


Use `--save` to write `chart.png` beside the script without opening a plot window.

![Generated chart](chart.png)

## Output

See [output.txt](output.txt) for the verified console output.
