# Practical 7: Confidence intervals using the t-distribution

## Aim

To compute 90%, 95% and 99% confidence intervals for the mean weight using the t-distribution.

Source: Statistics Lab manual-1_organized.pdf, PDF pages 10-11.

## Run

From the repository root, after installing `requirements.txt`:

```bash
python practical_07_confidence_intervals/main.py 248 249 250 251 252
```


## Source issue

Pages 10-11 repeat the sales mean/median/mode code from Practical 2 and provide no weight observations. The script implements the stated t-interval aim and requires the actual weight data as arguments. The command above uses **illustrative data only**, not observations from the manual.

The manual lists these intervals, but they cannot be reproduced or verified without its missing data:

```text
90% CI: (248.50, 251.50)
95% CI: (248.15, 251.85)
99% CI: (247.35, 252.65)
```

The original input printed in the manual is:

```python
import pandas as pd
sales = pd.Series([42, 38, 51, 29, 46, 34, 61, 40, 37, 44])
print("Mean:", sales.mean())
print("Median:", sales.median())
print("Mode:", sales.mode().tolist())
```

The script assumes independent observations and an approximately normal population when the sample is small. Intervals use the sample standard deviation and n - 1 degrees of freedom.

## Output

See [output.txt](output.txt) for the verified console output using the illustrative data above.
