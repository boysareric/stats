# Practical 4: Binomial probability distribution

## Aim

To generate the Binomial PMF for n = 5 and p = 0.3 and visualize it using a bar chart.

Source: Statistics Lab manual-1_organized.pdf, PDF pages 7.

## Run

From the repository root, after installing `requirements.txt`:

```bash
python practical_04_binomial_distribution/main.py
```


Use `--save` to write `chart.png` beside the script without opening a plot window.

![Generated chart](chart.png)

## Output

See [output.txt](output.txt) for the verified console output.
