# Practical 1: Student-score DataFrame

## Aim

To create and display a student-score data frame using Python and pandas.

Source: Statistics Lab manual-1_organized.pdf, PDF pages 4.

## Run

From the repository root, after installing `requirements.txt`:

```bash
python practical_01_student_scores/main.py
```


## Output

See [output.txt](output.txt) for the verified console output.
